<?php

//conectar la base de datos
$host = "localhost";
$user = "root";
$password = "";
$dbname = "opticateslavision";

$conn = new mysqli($host, $user, $password, $dbname);

?>